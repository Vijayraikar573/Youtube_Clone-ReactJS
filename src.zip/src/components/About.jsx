import React from 'react'

const About = () => {
  return (
    <div className='about'>
       
       <img src="/images/food.jpg" alt="" height={"400px"} weight={"300px"}/>
       <img src="/images/tree.jpg" alt="" height={"400px"} weight={"300px"}/>
       <img src="/images/book.jpg" alt="" height={"400px"} weight={"300px"}/>

    </div>
  )
}

export default About