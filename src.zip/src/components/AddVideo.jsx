import React from 'react'
import '../styles/AddVideo.css'
const AddVideo = () => {
  return (
    <div className='addvideo'>
        
        
        <div className='address'>
        <h1>AddVideo</h1>
        <div className='detail'>
        <input type="text" placeholder="Name" />
        <input type="email" placeholder="Email"/>
        <input type="text" placeholder="Subject"/>
        <input type="text" placeholder="create a message here" className='space'/>
        </div>
        
       
        <div className='btn'>
        <button>Add Video</button>
        </div>
        </div>
        
       
       <div className='img-video'>
          <img src="/images/gift.jpg" alt="" height={"600px"} width={"450px"}/>
       </div>
        
        </div>
  )
}

export default AddVideo